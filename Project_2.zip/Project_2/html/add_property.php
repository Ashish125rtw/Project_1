<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "Ashish@125";
$dbname = "real_estate";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $location = $_POST['location'];
    $propertyType = $_POST['property-type'];
    $bedrooms = $_POST['bedrooms'];
    $bathrooms = $_POST['bathrooms'];
    $area = $_POST['area'];
    $userId = 1; 

    // Insert property details into the properties table
    $stmt = $conn->prepare("INSERT INTO properties (title, description, price, location, property_type, bedrooms, bathrooms, area, user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdsiiiid", $title, $description, $price, $location, $propertyType, $bedrooms, $bathrooms, $area, $userId);

    if ($stmt->execute()) {
        $propertyId = $stmt->insert_id;

       
        $uploadDir = 'uploads/';
        foreach ($_FILES['images']['tmp_name'] as $key => $tmpName) {
            $fileName = basename($_FILES['images']['name'][$key]);
            $targetFilePath = $uploadDir . $fileName;

            if (move_uploaded_file($tmpName, $targetFilePath)) {
               
                $stmtImg = $conn->prepare("INSERT INTO property_images (property_id, image_path) VALUES (?, ?)");
                $stmtImg->bind_param("is", $propertyId, $targetFilePath);
                $stmtImg->execute();
            }
        }
        echo "Property added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
