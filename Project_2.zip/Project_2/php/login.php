<?php
session_start();

// Database connection details
$servername = "localhost";
$username = "root";
$password = "Ashish@125";
$dbname = "real_estate";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to sanitize input
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Handle login
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = sanitize($_POST['username']);
    $password = sanitize($_POST['password']);

    // Validate inputs
    if (empty($username) || empty($password)) {
        echo "Username and Password are required.";
    } else {
        // Prepare and execute SQL statement
        $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();
        
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id, $hashed_password);
            $stmt->fetch();
            
            // Verify password
            if (password_verify($password, $hashed_password)) {
                $_SESSION['user_id'] = $id;
                echo "Login successful!";
            } else {
                echo "Invalid password.";
            }
        } else {
            echo "Username not found.";
        }
        $stmt->close();
    }
}

// Close connection
$conn->close();
?>
