
    
    function validateEmail(email) {
        const re = /\S+@\S+\.\S+/;
        return re.test(email);
    }

    // Function to validate form inputs
    function validateForm() {
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const subject = document.getElementById('subject').value;
        const comment = document.getElementById('comment').value;

        if (name.trim() === '' || email.trim() === '' || subject.trim() === '' || comment.trim() === '') {
            alert('Please fill in all fields');
            return false;
        }

        if (!validateEmail(email)) {
            alert('Please enter a valid email address');
            return false;
        }

        return true;
    }

    // Function to handle form submission
    function submitForm(event) {
        event.preventDefault(); 

        // Validate form inputs
        if (!validateForm()) {
            return;
        }

        const formData = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            subject: document.getElementById('subject').value,
            comment: document.getElementById('comment').value
        };

        console.log('Form Data:', formData);
    }

    document.getElementById('contactForm').addEventListener('submit', submitForm);
